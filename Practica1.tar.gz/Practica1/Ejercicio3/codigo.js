var mes = prompt("Dime un mes")
if(mes == "enero" || mes == "diciembre" || mes == "febrero") {
    alert("Estamos en invierno")
}
else if (mes == "marzo" || mes == "abril" || mes == "mayo") {
    alert("Estamos en primavera")
}
else if (mes == "junio" || mes == "julio" || mes == "agosto") {
    alert("Estamos en verano")
}
else {
    alert("Estamos en otoño")
}

