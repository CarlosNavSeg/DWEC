function resize() {
    window.resizeTo(500, 500)

}