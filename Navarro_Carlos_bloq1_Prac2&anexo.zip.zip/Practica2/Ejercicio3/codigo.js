if(navigator.userAgent.indexOf('Chrome') != -1) {
alert('Chrome')
}
if(navigator.userAgent.indexOf('Firefox') != -1) {
    alert('Mozilla Firefox')
}
if(confirm('Quieres continuar?') == true) {
alert('Continuamos...')
}
else{

}

