alert(navigator.userAgent)
if(confirm('Quieres continuar?') == true) {
alert('Continuamos...')
}
else{

}

