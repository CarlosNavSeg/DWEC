function abrir() {
    window.open('./index copy.html')
}
function cerrar() {
    window.close()
}