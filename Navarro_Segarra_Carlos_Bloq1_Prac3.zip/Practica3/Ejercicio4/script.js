function contarImagenes() {
    var arrImg = document.getElementsByTagName('img')
    alert(arrImg.length)
}
function contarEnlaces() {
    var arrEnlace = document.getElementsByTagName('a')
    alert(arrEnlace.length)
}