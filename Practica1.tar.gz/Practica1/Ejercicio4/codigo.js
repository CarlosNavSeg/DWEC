var numero = prompt("Introduce un numero")
numero = parseInt(numero)
if(numero % 2 == 0) {
    alert("El numero es par")
} 
else {
    alert("El numero es im")
}