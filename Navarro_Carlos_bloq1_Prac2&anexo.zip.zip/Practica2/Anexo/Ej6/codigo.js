function hazLaSuma() {
    var cadena = "2+2"
    var resultado = eval(cadena)
    document.write(resultado)
}
